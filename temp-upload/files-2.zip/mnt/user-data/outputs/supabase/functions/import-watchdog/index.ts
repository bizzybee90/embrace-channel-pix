// ============================================================
// BIZZYBEE EMAIL IMPORT - WATCHDOG
// ============================================================
// This function monitors running import jobs and restarts any
// that appear stuck (no heartbeat for > 5 minutes).
//
// Deploy as a Supabase cron job to run every 5 minutes:
// SELECT cron.schedule('import-watchdog', '*/5 * * * *', 
//   $$SELECT net.http_post(
//     url := '<SUPABASE_URL>/functions/v1/import-watchdog',
//     headers := '{"Authorization": "Bearer <SERVICE_ROLE_KEY>"}'::jsonb
//   )$$
// );
// ============================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Job is considered stuck if no heartbeat for this long
const STALE_THRESHOLD_MS = 5 * 60 * 1000; // 5 minutes

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('[import-watchdog] Starting watchdog check');

    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Find stale jobs (running but no recent heartbeat)
    const staleThreshold = new Date(Date.now() - STALE_THRESHOLD_MS).toISOString();
    
    const { data: staleJobs, error: queryError } = await supabase
      .from('email_import_jobs')
      .select('id, config_id, status, checkpoint, heartbeat_at, retry_count')
      .in('status', ['scanning_inbox', 'scanning_sent', 'analyzing', 'fetching'])
      .lt('heartbeat_at', staleThreshold);

    if (queryError) {
      console.error('[import-watchdog] Query error:', queryError);
      return new Response(JSON.stringify({ error: 'Query failed' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`[import-watchdog] Found ${staleJobs?.length || 0} stale jobs`);

    const restarted: string[] = [];
    const failed: string[] = [];

    for (const job of staleJobs || []) {
      console.log(`[import-watchdog] Processing stale job: ${job.id}, status: ${job.status}`);

      // Check retry count
      if (job.retry_count >= 3) {
        console.log(`[import-watchdog] Job ${job.id} exceeded max retries, marking as error`);
        await supabase.from('email_import_jobs').update({
          status: 'error',
          error_message: 'Job stuck after multiple restart attempts'
        }).eq('id', job.id);
        failed.push(job.id);
        continue;
      }

      // Increment retry count
      await supabase.from('email_import_jobs').update({
        retry_count: (job.retry_count || 0) + 1,
        heartbeat_at: new Date().toISOString(),
      }).eq('id', job.id);

      // Determine which function to invoke based on status
      let functionName: string;
      switch (job.status) {
        case 'scanning_inbox':
        case 'scanning_sent':
          functionName = 'email-scan';
          break;
        case 'analyzing':
          functionName = 'email-analyze';
          break;
        case 'fetching':
          functionName = 'email-fetch-bodies';
          break;
        default:
          console.log(`[import-watchdog] Unknown status: ${job.status}`);
          continue;
      }

      console.log(`[import-watchdog] Restarting job ${job.id} with ${functionName}`);

      // Invoke the appropriate function
      const { error: invokeError } = await supabase.functions.invoke(functionName, {
        body: { 
          jobId: job.id, 
          configId: job.config_id,
          resume: true 
        }
      });

      if (invokeError) {
        console.error(`[import-watchdog] Failed to restart job ${job.id}:`, invokeError);
        failed.push(job.id);
      } else {
        console.log(`[import-watchdog] Successfully restarted job ${job.id}`);
        restarted.push(job.id);
      }
    }

    // Also check for retry queue items
    const { data: retries } = await supabase
      .from('email_fetch_retries')
      .select('*')
      .lt('next_retry_at', new Date().toISOString())
      .lt('attempt_count', 'max_attempts')
      .limit(50);

    console.log(`[import-watchdog] Found ${retries?.length || 0} pending retries`);

    // Process retries would go here (or in a separate function)

    return new Response(JSON.stringify({
      success: true,
      staleJobsFound: staleJobs?.length || 0,
      restarted,
      failed,
      pendingRetries: retries?.length || 0,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('[import-watchdog] Error:', error);
    return new Response(JSON.stringify({ error: String(error) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
