// ============================================================
// BIZZYBEE EMAIL IMPORT - PHASE 2: THREAD ANALYSIS
// ============================================================
// This function analyzes scanned emails to:
// 1. Mark noise emails (newsletters, receipts, etc.)
// 2. Group by thread_id
// 3. Identify conversation threads (have both inbound + outbound)
// 4. Queue conversation emails for body fetching
//
// This is mostly SQL-based = FAST (10-30 seconds)
// ============================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Edge runtime helper
declare const EdgeRuntime: { waitUntil: (promise: Promise<unknown>) => void } | undefined;
const waitUntil = (p: Promise<unknown>) => { try { EdgeRuntime?.waitUntil(p); } catch {} };

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();

  try {
    const { jobId, configId } = await req.json();
    console.log('[email-analyze] Starting:', { jobId, configId });

    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Get job
    const { data: job, error: jobError } = await supabase
      .from('email_import_jobs')
      .select('*')
      .eq('id', jobId)
      .single();

    if (jobError || !job) {
      console.error('[email-analyze] Job not found:', jobError);
      return new Response(JSON.stringify({ error: 'Job not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Check if cancelled
    if (job.status === 'cancelled') {
      return new Response(JSON.stringify({ cancelled: true }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Update status
    await supabase.from('email_import_jobs').update({
      status: 'analyzing',
      heartbeat_at: new Date().toISOString(),
    }).eq('id', jobId);

    // Get config for workspace_id
    const { data: config } = await supabase
      .from('email_provider_configs')
      .select('workspace_id')
      .eq('id', configId)
      .single();

    if (!config) {
      await supabase.from('email_import_jobs').update({
        status: 'error',
        error_message: 'Config not found'
      }).eq('id', jobId);
      return new Response(JSON.stringify({ error: 'Config not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log('[email-analyze] Step 1: Marking noise emails...');

    // STEP 1: Mark noise emails using SQL function
    const { data: noiseCount, error: noiseError } = await supabase
      .rpc('mark_noise_emails', {
        p_workspace_id: config.workspace_id,
        p_job_id: jobId
      });

    if (noiseError) {
      console.error('[email-analyze] Noise marking error:', noiseError);
    } else {
      console.log(`[email-analyze] Marked ${noiseCount} noise emails`);
    }

    // Also filter out emails FROM connected account (outbound in inbox)
    const { data: emailConfig } = await supabase
      .from('email_provider_configs')
      .select('email_address, aliases')
      .eq('id', configId)
      .single();

    if (emailConfig) {
      const connectedEmails = [
        emailConfig.email_address.toLowerCase(),
        ...(emailConfig.aliases || []).map((a: string) => a.toLowerCase())
      ];

      // Mark outbound emails that appear in inbox as not needing fetch
      const { error: selfEmailError } = await supabase
        .from('email_import_queue')
        .update({ 
          is_noise: true, 
          noise_reason: 'self_sent',
          status: 'skipped'
        })
        .eq('job_id', jobId)
        .eq('direction', 'inbound')
        .in('from_email', connectedEmails);

      if (selfEmailError) {
        console.error('[email-analyze] Self-email filter error:', selfEmailError);
      }
    }

    console.log('[email-analyze] Step 2: Analyzing threads...');

    // STEP 2: Run thread analysis using SQL function
    const { data: analysisResult, error: analysisError } = await supabase
      .rpc('analyze_email_threads', {
        p_workspace_id: config.workspace_id,
        p_job_id: jobId
      });

    if (analysisError) {
      console.error('[email-analyze] Thread analysis error:', analysisError);
      await supabase.from('email_import_jobs').update({
        status: 'error',
        error_message: 'Thread analysis failed: ' + analysisError.message
      }).eq('id', jobId);
      return new Response(JSON.stringify({ error: 'Analysis failed' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const stats = analysisResult?.[0] || { threads_analyzed: 0, conversation_threads: 0, noise_threads: 0 };
    console.log('[email-analyze] Thread analysis result:', stats);

    console.log('[email-analyze] Step 3: Queuing emails for body fetch...');

    // STEP 3: Mark conversation thread emails for body fetching
    // Only fetch emails from threads that have BOTH inbound and outbound
    const { data: conversationThreads } = await supabase
      .from('email_thread_analysis')
      .select('thread_id')
      .eq('job_id', jobId)
      .eq('is_conversation', true)
      .eq('is_noise_thread', false);

    const threadIds = conversationThreads?.map(t => t.thread_id) || [];
    console.log(`[email-analyze] Found ${threadIds.length} conversation threads to fetch`);

    if (threadIds.length > 0) {
      // Update emails in conversation threads to be queued for fetch
      // Process in batches to avoid query size limits
      const BATCH_SIZE = 500;
      for (let i = 0; i < threadIds.length; i += BATCH_SIZE) {
        const batch = threadIds.slice(i, i + BATCH_SIZE);
        
        const { error: queueError } = await supabase
          .from('email_import_queue')
          .update({ status: 'queued_for_fetch' })
          .eq('job_id', jobId)
          .eq('is_noise', false)
          .in('thread_id', batch);

        if (queueError) {
          console.error(`[email-analyze] Queue batch ${i} error:`, queueError);
        }
      }
    }

    // Count queued emails
    const { count: queuedCount } = await supabase
      .from('email_import_queue')
      .select('*', { count: 'exact', head: true })
      .eq('job_id', jobId)
      .eq('status', 'queued_for_fetch');

    console.log(`[email-analyze] Queued ${queuedCount} emails for body fetch`);

    // Update job with analysis results
    await supabase.from('email_import_jobs').update({
      status: 'fetching',
      total_threads_found: stats.threads_analyzed,
      conversation_threads: stats.conversation_threads,
      heartbeat_at: new Date().toISOString(),
    }).eq('id', jobId);

    console.log('[email-analyze] Analysis complete, triggering body fetch');

    // Trigger body fetch phase
    waitUntil(
      supabase.functions.invoke('email-fetch-bodies', {
        body: { jobId, configId }
      }).then(({ error }) => {
        if (error) console.error('[email-analyze] Failed to trigger fetch:', error);
      })
    );

    return new Response(JSON.stringify({
      success: true,
      threadsAnalyzed: stats.threads_analyzed,
      conversationThreads: stats.conversation_threads,
      noiseThreads: stats.noise_threads,
      emailsQueuedForFetch: queuedCount,
      elapsedMs: Date.now() - startTime,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('[email-analyze] Error:', error);
    return new Response(JSON.stringify({ error: String(error) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
