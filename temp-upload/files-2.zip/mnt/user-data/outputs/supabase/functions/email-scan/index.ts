// ============================================================
// BIZZYBEE EMAIL IMPORT - PHASE 1: FAST METADATA SCAN
// ============================================================
// This function scans inbox and sent folders, storing metadata only.
// No individual message fetches = FAST (2-3 minutes for 16k emails)
// 
// Features:
// - Checkpointing for resume capability
// - Heartbeat for watchdog monitoring
// - Self-continuation for long imports
// - Bulk upserts for speed
// ============================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Configuration
const BATCH_SIZE = 100;           // Aurinko max per page
const MAX_RUNTIME_MS = 25000;     // 25s (leave buffer before 30s timeout)
const HEARTBEAT_INTERVAL_MS = 5000;

// Edge runtime helper
declare const EdgeRuntime: { waitUntil: (promise: Promise<unknown>) => void } | undefined;
const waitUntil = (p: Promise<unknown>) => { try { EdgeRuntime?.waitUntil(p); } catch {} };

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();
  
  try {
    const { jobId, configId, resume = false } = await req.json();
    console.log('[email-scan] Starting:', { jobId, configId, resume });

    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Get job
    const { data: job, error: jobError } = await supabase
      .from('email_import_jobs')
      .select('*')
      .eq('id', jobId)
      .single();

    if (jobError || !job) {
      console.error('[email-scan] Job not found:', jobError);
      return new Response(JSON.stringify({ error: 'Job not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Check if job was cancelled
    if (job.status === 'cancelled') {
      console.log('[email-scan] Job cancelled, exiting');
      return new Response(JSON.stringify({ cancelled: true }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Get email config
    const { data: config, error: configError } = await supabase
      .from('email_provider_configs')
      .select('*')
      .eq('id', configId)
      .single();

    if (configError || !config) {
      await updateJobError(supabase, jobId, 'Email config not found');
      return new Response(JSON.stringify({ error: 'Config not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Parse checkpoint
    const checkpoint = job.checkpoint || {};
    let phase: 'inbox' | 'sent' | 'done' = checkpoint.phase || 'inbox';
    let pageToken: string | null = checkpoint.page_token || null;
    let inboxScanned = job.inbox_emails_scanned || 0;
    let sentScanned = job.sent_emails_scanned || 0;

    console.log('[email-scan] Resuming from checkpoint:', { phase, pageToken, inboxScanned, sentScanned });

    // Update job status
    const newStatus = phase === 'inbox' ? 'scanning_inbox' : 'scanning_sent';
    await supabase.from('email_import_jobs').update({
      status: newStatus,
      started_at: job.started_at || new Date().toISOString(),
      heartbeat_at: new Date().toISOString(),
    }).eq('id', jobId);

    // Heartbeat interval
    const heartbeatInterval = setInterval(async () => {
      await supabase.from('email_import_jobs').update({
        heartbeat_at: new Date().toISOString()
      }).eq('id', jobId);
    }, HEARTBEAT_INTERVAL_MS);

    let needsContinuation = false;
    let batchesProcessed = 0;

    try {
      // SCAN LOOP
      while (phase !== 'done' && Date.now() - startTime < MAX_RUNTIME_MS) {
        const folder = phase === 'inbox' ? 'INBOX' : 'SENT';
        
        // Build URL
        let url = `https://api.aurinko.io/v1/email/messages?folder=${folder}&limit=${BATCH_SIZE}`;
        if (pageToken) {
          url += `&pageToken=${pageToken}`;
        }

        console.log(`[email-scan] Fetching ${folder}:`, { pageToken: pageToken?.substring(0, 20) });

        // Fetch from Aurinko
        const response = await fetch(url, {
          headers: { 'Authorization': `Bearer ${config.access_token}` }
        });

        if (!response.ok) {
          const errorText = await response.text();
          console.error('[email-scan] Aurinko error:', response.status, errorText);
          
          // Handle token expiration
          if (response.status === 401) {
            await updateJobError(supabase, jobId, 'Access token expired. Please reconnect your email.');
            break;
          }
          
          // Handle rate limiting
          if (response.status === 429) {
            console.log('[email-scan] Rate limited, will retry in next invocation');
            needsContinuation = true;
            break;
          }
          
          // Other errors
          await updateJobError(supabase, jobId, `API error: ${response.status} - ${errorText.substring(0, 200)}`);
          break;
        }

        const data = await response.json();
        const messages = data.records || [];
        const nextPageToken = data.nextPageToken || null;

        console.log(`[email-scan] Got ${messages.length} messages, nextPage: ${!!nextPageToken}`);

        if (messages.length > 0) {
          // Transform to queue format
          const rows = messages.map((msg: any) => ({
            workspace_id: config.workspace_id,
            config_id: configId,
            job_id: jobId,
            external_id: msg.id?.toString(),
            thread_id: msg.threadId?.toString() || msg.id?.toString(),
            direction: phase === 'inbox' ? 'inbound' : 'outbound',
            from_email: (msg.from?.address || msg.from?.email || '').toLowerCase(),
            from_name: msg.from?.name || null,
            to_emails: msg.to?.map((t: any) => (t.address || t.email || '').toLowerCase()) || [],
            subject: msg.subject || null,
            received_at: msg.receivedAt || msg.createdAt || null,
            status: 'scanned',
          }));

          // Bulk upsert (fast!)
          const { error: upsertError } = await supabase
            .from('email_import_queue')
            .upsert(rows, { 
              onConflict: 'workspace_id,external_id',
              ignoreDuplicates: true 
            });

          if (upsertError) {
            console.error('[email-scan] Upsert error:', upsertError);
          }

          // Update counts
          if (phase === 'inbox') {
            inboxScanned += messages.length;
          } else {
            sentScanned += messages.length;
          }

          batchesProcessed++;
        }

        // Move to next page or next phase
        if (nextPageToken) {
          pageToken = nextPageToken;
          needsContinuation = true;
        } else {
          // Phase complete
          if (phase === 'inbox') {
            console.log('[email-scan] Inbox scan complete, moving to sent');
            phase = 'sent';
            pageToken = null;
            needsContinuation = true; // Continue to sent phase
          } else {
            console.log('[email-scan] Sent scan complete');
            phase = 'done';
            needsContinuation = false;
          }
        }

        // Save checkpoint after each batch
        await supabase.from('email_import_jobs').update({
          checkpoint: { phase, page_token: pageToken },
          inbox_emails_scanned: inboxScanned,
          sent_emails_scanned: sentScanned,
          status: phase === 'done' ? 'analyzing' : (phase === 'inbox' ? 'scanning_inbox' : 'scanning_sent'),
          heartbeat_at: new Date().toISOString(),
        }).eq('id', jobId);

        // Check time
        if (Date.now() - startTime > MAX_RUNTIME_MS) {
          console.log('[email-scan] Approaching timeout, saving progress');
          needsContinuation = phase !== 'done';
          break;
        }
      }
    } finally {
      clearInterval(heartbeatInterval);
    }

    // Update final status
    if (phase === 'done') {
      console.log('[email-scan] Scan complete, triggering analysis');
      
      await supabase.from('email_import_jobs').update({
        status: 'analyzing',
        checkpoint: { phase: 'done' },
        inbox_emails_scanned: inboxScanned,
        sent_emails_scanned: sentScanned,
        heartbeat_at: new Date().toISOString(),
      }).eq('id', jobId);

      // Trigger analysis phase
      waitUntil(
        supabase.functions.invoke('email-analyze', {
          body: { jobId, configId }
        }).then(({ error }) => {
          if (error) console.error('[email-scan] Failed to trigger analysis:', error);
        })
      );

    } else if (needsContinuation) {
      console.log('[email-scan] Scheduling continuation');
      
      // Self-invoke to continue
      waitUntil(
        supabase.functions.invoke('email-scan', {
          body: { jobId, configId, resume: true }
        }).then(({ error }) => {
          if (error) console.error('[email-scan] Failed to schedule continuation:', error);
        })
      );
    }

    return new Response(JSON.stringify({
      success: true,
      phase,
      inboxScanned,
      sentScanned,
      batchesProcessed,
      needsContinuation,
      elapsedMs: Date.now() - startTime,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('[email-scan] Error:', error);
    return new Response(JSON.stringify({ error: String(error) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});

// Helper to update job with error
async function updateJobError(supabase: any, jobId: string, message: string) {
  await supabase.from('email_import_jobs').update({
    status: 'error',
    error_message: message,
  }).eq('id', jobId);
}
