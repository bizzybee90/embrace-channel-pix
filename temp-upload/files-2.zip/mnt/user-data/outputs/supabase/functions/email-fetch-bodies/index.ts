// ============================================================
// BIZZYBEE EMAIL IMPORT - PHASE 3: SELECTIVE BODY FETCH
// ============================================================
// This function fetches full message bodies ONLY for emails in
// conversation threads (threads with both inbound + outbound).
//
// Instead of fetching 16,500 bodies, we fetch ~2,500.
//
// Features:
// - Checkpointing for resume
// - Retry logic with exponential backoff
// - Rate limiting awareness
// - Creates conversations + messages in final tables
// ============================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Configuration
const BATCH_SIZE = 30;            // Emails to fetch per invocation
const MAX_RUNTIME_MS = 25000;     // 25s timeout buffer
const RETRY_DELAYS = [1000, 3000, 10000]; // Exponential backoff

// Edge runtime helper
declare const EdgeRuntime: { waitUntil: (promise: Promise<unknown>) => void } | undefined;
const waitUntil = (p: Promise<unknown>) => { try { EdgeRuntime?.waitUntil(p); } catch {} };

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();

  try {
    const { jobId, configId } = await req.json();
    console.log('[email-fetch-bodies] Starting:', { jobId, configId });

    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Get job
    const { data: job, error: jobError } = await supabase
      .from('email_import_jobs')
      .select('*')
      .eq('id', jobId)
      .single();

    if (jobError || !job) {
      return new Response(JSON.stringify({ error: 'Job not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (job.status === 'cancelled') {
      return new Response(JSON.stringify({ cancelled: true }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Get config
    const { data: config, error: configError } = await supabase
      .from('email_provider_configs')
      .select('*')
      .eq('id', configId)
      .single();

    if (configError || !config) {
      await updateJobError(supabase, jobId, 'Config not found');
      return new Response(JSON.stringify({ error: 'Config not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Update status
    await supabase.from('email_import_jobs').update({
      status: 'fetching',
      heartbeat_at: new Date().toISOString(),
    }).eq('id', jobId);

    // Get emails queued for fetch
    const { data: emailsToFetch, error: fetchError } = await supabase
      .from('email_import_queue')
      .select('*')
      .eq('job_id', jobId)
      .eq('status', 'queued_for_fetch')
      .order('received_at', { ascending: false })
      .limit(BATCH_SIZE);

    if (fetchError) {
      console.error('[email-fetch-bodies] Query error:', fetchError);
      await updateJobError(supabase, jobId, 'Failed to query emails: ' + fetchError.message);
      return new Response(JSON.stringify({ error: 'Query failed' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`[email-fetch-bodies] Found ${emailsToFetch?.length || 0} emails to fetch`);

    if (!emailsToFetch || emailsToFetch.length === 0) {
      // No more emails to fetch - move to training phase
      console.log('[email-fetch-bodies] All bodies fetched, completing job');
      
      await supabase.from('email_import_jobs').update({
        status: 'completed',
        completed_at: new Date().toISOString(),
        heartbeat_at: new Date().toISOString(),
      }).eq('id', jobId);

      // Update email config status
      await supabase.from('email_provider_configs').update({
        sync_status: 'completed',
        sync_completed_at: new Date().toISOString(),
      }).eq('id', configId);

      // Trigger style analysis (optional - can be separate step)
      waitUntil(
        supabase.functions.invoke('analyze-voice-profile', {
          body: { workspace_id: config.workspace_id }
        }).catch(err => console.log('[email-fetch-bodies] Voice analysis not triggered:', err))
      );

      return new Response(JSON.stringify({
        success: true,
        completed: true,
        elapsedMs: Date.now() - startTime,
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Connected emails for direction detection
    const connectedEmails = [
      config.email_address.toLowerCase(),
      ...(config.aliases || []).map((a: string) => a.toLowerCase())
    ];

    let bodiesFetched = 0;
    let messagesCreated = 0;
    let errors = 0;

    // Process each email
    for (const email of emailsToFetch) {
      // Check timeout
      if (Date.now() - startTime > MAX_RUNTIME_MS) {
        console.log('[email-fetch-bodies] Approaching timeout, will continue');
        break;
      }

      try {
        // Fetch full message from Aurinko
        const fullMessage = await fetchWithRetry(
          email.external_id,
          config.access_token,
          supabase,
          config.workspace_id,
          jobId
        );

        if (!fullMessage) {
          // Failed after retries - mark as error
          await supabase.from('email_import_queue').update({
            status: 'error',
            error_message: 'Failed to fetch after retries'
          }).eq('id', email.id);
          errors++;
          continue;
        }

        // Extract body
        const body = extractBody(fullMessage);
        const bodyHtml = fullMessage.body?.html || fullMessage.htmlBody || null;

        // Update queue with body
        await supabase.from('email_import_queue').update({
          body: body?.substring(0, 50000),
          body_html: bodyHtml?.substring(0, 100000),
          has_body: true,
          status: 'fetched',
          fetched_at: new Date().toISOString(),
        }).eq('id', email.id);

        bodiesFetched++;

        // Now create/update conversation and message
        const result = await createOrUpdateConversation(
          supabase,
          config,
          email,
          fullMessage,
          body,
          connectedEmails
        );

        if (result.messageCreated) {
          messagesCreated++;
        }

      } catch (err) {
        console.error(`[email-fetch-bodies] Error processing ${email.external_id}:`, err);
        errors++;
        
        await supabase.from('email_import_queue').update({
          status: 'error',
          error_message: String(err).substring(0, 500)
        }).eq('id', email.id);
      }
    }

    // Update job progress
    const { data: currentJob } = await supabase
      .from('email_import_jobs')
      .select('bodies_fetched, messages_created')
      .eq('id', jobId)
      .single();

    await supabase.from('email_import_jobs').update({
      bodies_fetched: (currentJob?.bodies_fetched || 0) + bodiesFetched,
      messages_created: (currentJob?.messages_created || 0) + messagesCreated,
      heartbeat_at: new Date().toISOString(),
    }).eq('id', jobId);

    // Check if more emails to process
    const { count: remainingCount } = await supabase
      .from('email_import_queue')
      .select('*', { count: 'exact', head: true })
      .eq('job_id', jobId)
      .eq('status', 'queued_for_fetch');

    console.log(`[email-fetch-bodies] Batch complete. Fetched: ${bodiesFetched}, Remaining: ${remainingCount}`);

    if (remainingCount && remainingCount > 0) {
      // Schedule continuation
      waitUntil(
        supabase.functions.invoke('email-fetch-bodies', {
          body: { jobId, configId }
        }).then(({ error }) => {
          if (error) console.error('[email-fetch-bodies] Continuation failed:', error);
        })
      );
    } else {
      // All done!
      console.log('[email-fetch-bodies] All emails processed, completing job');
      
      await supabase.from('email_import_jobs').update({
        status: 'completed',
        completed_at: new Date().toISOString(),
      }).eq('id', jobId);

      await supabase.from('email_provider_configs').update({
        sync_status: 'completed',
        sync_completed_at: new Date().toISOString(),
      }).eq('id', configId);
    }

    return new Response(JSON.stringify({
      success: true,
      bodiesFetched,
      messagesCreated,
      errors,
      remaining: remainingCount,
      elapsedMs: Date.now() - startTime,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('[email-fetch-bodies] Error:', error);
    return new Response(JSON.stringify({ error: String(error) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});


// ============================================================
// HELPER FUNCTIONS
// ============================================================

async function fetchWithRetry(
  externalId: string,
  accessToken: string,
  supabase: any,
  workspaceId: string,
  jobId: string
): Promise<any | null> {
  
  for (let attempt = 0; attempt < RETRY_DELAYS.length; attempt++) {
    try {
      const response = await fetch(
        `https://api.aurinko.io/v1/email/messages/${externalId}`,
        { headers: { 'Authorization': `Bearer ${accessToken}` } }
      );

      if (response.ok) {
        return await response.json();
      }

      if (response.status === 429) {
        // Rate limited - wait and retry
        console.log(`[email-fetch-bodies] Rate limited, waiting ${RETRY_DELAYS[attempt]}ms`);
        await sleep(RETRY_DELAYS[attempt]);
        continue;
      }

      if (response.status >= 500) {
        // Server error - retry
        console.log(`[email-fetch-bodies] Server error ${response.status}, retrying`);
        await sleep(RETRY_DELAYS[attempt]);
        continue;
      }

      // 4xx (except 429) - don't retry
      console.log(`[email-fetch-bodies] Client error ${response.status} for ${externalId}`);
      return null;

    } catch (err) {
      console.error(`[email-fetch-bodies] Fetch error attempt ${attempt}:`, err);
      await sleep(RETRY_DELAYS[attempt]);
    }
  }

  // Add to retry queue for later processing
  await supabase.from('email_fetch_retries').upsert({
    workspace_id: workspaceId,
    job_id: jobId,
    external_id: externalId,
    attempt_count: RETRY_DELAYS.length,
    last_error: 'Max retries exceeded',
    next_retry_at: new Date(Date.now() + 60000).toISOString(), // 1 min
  }, { onConflict: 'workspace_id,external_id' });

  return null;
}


function extractBody(message: any): string {
  // Try plain text first
  let body = message.textBody || message.body?.text || '';
  
  // Fall back to HTML stripped
  if (!body && (message.body?.html || message.htmlBody)) {
    body = stripHtml(message.body?.html || message.htmlBody);
  }

  // Strip quoted content (but keep something if stripping removes everything)
  const stripped = body
    .split(/^On .+ wrote:$/m)[0]
    .split(/^-{2,}\s*Original Message/mi)[0]
    .split(/^From:/mi)[0]
    .split(/^>+\s/m)[0]
    .trim();

  return stripped.length > 10 ? stripped : body.trim();
}


function stripHtml(html: string): string {
  return html
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}


async function createOrUpdateConversation(
  supabase: any,
  config: any,
  queuedEmail: any,
  fullMessage: any,
  body: string,
  connectedEmails: string[]
): Promise<{ conversationId: string | null; messageCreated: boolean }> {
  
  const threadId = queuedEmail.thread_id;
  const direction = queuedEmail.direction;
  const fromEmail = queuedEmail.from_email;
  const fromName = queuedEmail.from_name || fromEmail?.split('@')[0] || 'Unknown';
  const subject = queuedEmail.subject || 'No Subject';
  const receivedAt = queuedEmail.received_at || fullMessage.receivedAt || fullMessage.createdAt;

  // Check if conversation already exists for this thread
  let conversationId: string | null = null;

  // Try to find by thread_id in metadata
  const { data: existingConv } = await supabase
    .from('conversations')
    .select('id')
    .eq('workspace_id', config.workspace_id)
    .contains('metadata', { thread_id: threadId })
    .limit(1)
    .maybeSingle();

  if (existingConv) {
    conversationId = existingConv.id;
  } else {
    // Try external_conversation_id
    const { data: existingConv2 } = await supabase
      .from('conversations')
      .select('id')
      .eq('workspace_id', config.workspace_id)
      .or(`external_conversation_id.eq.${threadId},external_conversation_id.eq.aurinko_${threadId}`)
      .limit(1)
      .maybeSingle();

    if (existingConv2) {
      conversationId = existingConv2.id;
    }
  }

  // If no conversation and this is inbound, create one
  if (!conversationId && direction === 'inbound') {
    // Find or create customer
    let customerId: string | null = null;
    
    const { data: existingCustomer } = await supabase
      .from('customers')
      .select('id')
      .eq('workspace_id', config.workspace_id)
      .eq('email', fromEmail)
      .single();

    if (existingCustomer) {
      customerId = existingCustomer.id;
    } else {
      const { data: newCustomer } = await supabase
        .from('customers')
        .insert({
          workspace_id: config.workspace_id,
          email: fromEmail,
          name: fromName,
          preferred_channel: 'email',
        })
        .select('id')
        .single();
      
      customerId = newCustomer?.id || null;
    }

    if (customerId) {
      // Create conversation
      const { data: newConv } = await supabase
        .from('conversations')
        .insert({
          workspace_id: config.workspace_id,
          customer_id: customerId,
          channel: 'email',
          title: subject,
          status: 'closed', // Historical email
          external_conversation_id: `aurinko_${threadId}`,
          metadata: { 
            thread_id: threadId, 
            email_provider: config.provider,
            imported: true 
          },
          created_at: receivedAt,
        })
        .select('id')
        .single();

      conversationId = newConv?.id || null;
    }
  }

  // If we have a conversation, add the message
  if (conversationId && body && body.length >= 5) {
    // Check if message already exists
    const { data: existingMsg } = await supabase
      .from('messages')
      .select('id')
      .eq('conversation_id', conversationId)
      .eq('raw_payload->>id', queuedEmail.external_id)
      .maybeSingle();

    if (!existingMsg) {
      const isOutbound = direction === 'outbound' || connectedEmails.includes(fromEmail);
      
      const { error: msgError } = await supabase.from('messages').insert({
        conversation_id: conversationId,
        body: body.substring(0, 10000),
        direction: isOutbound ? 'outbound' : 'inbound',
        channel: 'email',
        actor_type: isOutbound ? 'human_agent' : 'customer',
        actor_name: fromName,
        created_at: receivedAt,
        raw_payload: fullMessage,
      });

      if (msgError) {
        console.error('[email-fetch-bodies] Message insert error:', msgError);
        return { conversationId, messageCreated: false };
      }

      // Mark email as processed
      await supabase.from('email_import_queue').update({
        status: 'processed',
        processed_at: new Date().toISOString(),
      }).eq('id', queuedEmail.id);

      return { conversationId, messageCreated: true };
    }
  }

  return { conversationId, messageCreated: false };
}


async function updateJobError(supabase: any, jobId: string, message: string) {
  await supabase.from('email_import_jobs').update({
    status: 'error',
    error_message: message,
  }).eq('id', jobId);
}


function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
