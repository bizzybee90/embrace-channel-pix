-- ============================================================
-- BIZZYBEE EMAIL IMPORT SYSTEM - DATABASE SCHEMA
-- ============================================================
-- This migration creates tables for the 2-phase email import:
-- Phase 1: Fast metadata scan (no bodies)
-- Phase 2: Selective body fetch (conversations only)
-- ============================================================

-- Drop existing tables if they exist (be careful in production!)
-- DROP TABLE IF EXISTS email_fetch_retries CASCADE;
-- DROP TABLE IF EXISTS email_import_queue CASCADE;
-- DROP TABLE IF EXISTS email_import_jobs CASCADE;

-- ============================================================
-- TABLE: email_import_jobs
-- Main job tracking with checkpointing for reliability
-- ============================================================
CREATE TABLE IF NOT EXISTS email_import_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  config_id UUID NOT NULL REFERENCES email_provider_configs(id) ON DELETE CASCADE,
  
  -- Status tracking
  status TEXT NOT NULL DEFAULT 'queued' 
    CHECK (status IN ('queued', 'scanning_inbox', 'scanning_sent', 'analyzing', 'fetching', 'training', 'completed', 'error', 'cancelled', 'paused')),
  
  -- Progress counters
  inbox_emails_scanned INT DEFAULT 0,
  sent_emails_scanned INT DEFAULT 0,
  total_threads_found INT DEFAULT 0,
  conversation_threads INT DEFAULT 0,  -- Threads with both inbound + outbound
  bodies_fetched INT DEFAULT 0,
  bodies_skipped INT DEFAULT 0,
  messages_created INT DEFAULT 0,
  
  -- Checkpointing for resume capability
  checkpoint JSONB DEFAULT '{}',
  -- Example checkpoint:
  -- {
  --   "phase": "scanning_inbox",
  --   "page_token": "abc123",
  --   "last_external_id": "12345"
  -- }
  
  -- Heartbeat for watchdog
  heartbeat_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Timing
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  
  -- Error handling
  error_message TEXT,
  error_details JSONB,
  retry_count INT DEFAULT 0,
  
  -- Metadata
  import_mode TEXT DEFAULT 'last_1000',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for finding running jobs (watchdog)
CREATE INDEX IF NOT EXISTS idx_import_jobs_status 
  ON email_import_jobs(status);

CREATE INDEX IF NOT EXISTS idx_import_jobs_heartbeat 
  ON email_import_jobs(heartbeat_at) 
  WHERE status IN ('scanning_inbox', 'scanning_sent', 'analyzing', 'fetching');

CREATE INDEX IF NOT EXISTS idx_import_jobs_workspace 
  ON email_import_jobs(workspace_id);


-- ============================================================
-- TABLE: email_import_queue
-- Raw email metadata from Phase 1, bodies added in Phase 2
-- ============================================================
CREATE TABLE IF NOT EXISTS email_import_queue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  config_id UUID NOT NULL REFERENCES email_provider_configs(id) ON DELETE CASCADE,
  job_id UUID REFERENCES email_import_jobs(id) ON DELETE SET NULL,
  
  -- Email identity
  external_id TEXT NOT NULL,
  thread_id TEXT NOT NULL,
  
  -- Direction
  direction TEXT NOT NULL CHECK (direction IN ('inbound', 'outbound')),
  
  -- Metadata (from Phase 1 - list endpoint)
  from_email TEXT,
  from_name TEXT,
  to_emails TEXT[],
  subject TEXT,
  received_at TIMESTAMPTZ,
  
  -- Classification (set during analysis)
  is_noise BOOLEAN DEFAULT FALSE,  -- newsletters, receipts, etc.
  noise_reason TEXT,  -- 'noreply', 'newsletter', 'receipt', etc.
  
  -- Body (from Phase 2 - individual fetch)
  body TEXT,
  body_html TEXT,
  has_body BOOLEAN DEFAULT FALSE,
  
  -- Processing status
  status TEXT DEFAULT 'scanned' 
    CHECK (status IN ('scanned', 'queued_for_fetch', 'fetched', 'processed', 'skipped', 'error')),
  error_message TEXT,
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  fetched_at TIMESTAMPTZ,
  processed_at TIMESTAMPTZ,
  
  -- Unique constraint prevents duplicates
  UNIQUE(workspace_id, external_id)
);

-- Indexes for fast querying
CREATE INDEX IF NOT EXISTS idx_email_queue_thread 
  ON email_import_queue(workspace_id, thread_id);

CREATE INDEX IF NOT EXISTS idx_email_queue_direction 
  ON email_import_queue(workspace_id, direction);

CREATE INDEX IF NOT EXISTS idx_email_queue_status 
  ON email_import_queue(workspace_id, status);

CREATE INDEX IF NOT EXISTS idx_email_queue_job 
  ON email_import_queue(job_id);

CREATE INDEX IF NOT EXISTS idx_email_queue_noise 
  ON email_import_queue(workspace_id, is_noise) 
  WHERE is_noise = FALSE;


-- ============================================================
-- TABLE: email_fetch_retries
-- Failed fetches that need retry
-- ============================================================
CREATE TABLE IF NOT EXISTS email_fetch_retries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  job_id UUID REFERENCES email_import_jobs(id) ON DELETE CASCADE,
  external_id TEXT NOT NULL,
  
  -- Retry tracking
  attempt_count INT DEFAULT 1,
  max_attempts INT DEFAULT 3,
  last_error TEXT,
  last_status_code INT,
  
  -- Scheduling
  next_retry_at TIMESTAMPTZ DEFAULT NOW(),
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(workspace_id, external_id)
);

CREATE INDEX IF NOT EXISTS idx_email_retries_next 
  ON email_fetch_retries(next_retry_at) 
  WHERE attempt_count < max_attempts;


-- ============================================================
-- TABLE: email_thread_analysis
-- Results of thread grouping (which threads are conversations)
-- ============================================================
CREATE TABLE IF NOT EXISTS email_thread_analysis (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  job_id UUID REFERENCES email_import_jobs(id) ON DELETE CASCADE,
  
  thread_id TEXT NOT NULL,
  
  -- Counts
  inbound_count INT DEFAULT 0,
  outbound_count INT DEFAULT 0,
  total_count INT DEFAULT 0,
  
  -- Classification
  is_conversation BOOLEAN DEFAULT FALSE,  -- Has both inbound AND outbound
  is_noise_thread BOOLEAN DEFAULT FALSE,  -- All emails are noise
  
  -- Representative emails (for fetching)
  first_inbound_id TEXT,
  first_outbound_id TEXT,
  latest_inbound_id TEXT,
  latest_outbound_id TEXT,
  
  -- Processing
  needs_body_fetch BOOLEAN DEFAULT FALSE,
  bodies_fetched BOOLEAN DEFAULT FALSE,
  conversation_created BOOLEAN DEFAULT FALSE,
  conversation_id UUID REFERENCES conversations(id),
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(workspace_id, thread_id)
);

CREATE INDEX IF NOT EXISTS idx_thread_analysis_conversation 
  ON email_thread_analysis(workspace_id, is_conversation) 
  WHERE is_conversation = TRUE;

CREATE INDEX IF NOT EXISTS idx_thread_analysis_needs_fetch 
  ON email_thread_analysis(workspace_id, needs_body_fetch) 
  WHERE needs_body_fetch = TRUE AND bodies_fetched = FALSE;


-- ============================================================
-- FUNCTION: analyze_email_threads
-- Groups emails by thread, identifies conversations
-- ============================================================
CREATE OR REPLACE FUNCTION analyze_email_threads(p_workspace_id UUID, p_job_id UUID)
RETURNS TABLE(
  threads_analyzed INT,
  conversation_threads INT,
  noise_threads INT
) 
LANGUAGE plpgsql
AS $$
DECLARE
  v_threads_analyzed INT;
  v_conversation_threads INT;
  v_noise_threads INT;
BEGIN
  -- Clear previous analysis for this job
  DELETE FROM email_thread_analysis WHERE job_id = p_job_id;
  
  -- Insert thread analysis
  INSERT INTO email_thread_analysis (
    workspace_id,
    job_id,
    thread_id,
    inbound_count,
    outbound_count,
    total_count,
    is_conversation,
    is_noise_thread,
    first_inbound_id,
    first_outbound_id,
    latest_inbound_id,
    latest_outbound_id,
    needs_body_fetch
  )
  SELECT 
    p_workspace_id,
    p_job_id,
    eq.thread_id,
    COUNT(*) FILTER (WHERE eq.direction = 'inbound') as inbound_count,
    COUNT(*) FILTER (WHERE eq.direction = 'outbound') as outbound_count,
    COUNT(*) as total_count,
    -- Is conversation: has both inbound AND outbound
    (COUNT(*) FILTER (WHERE eq.direction = 'inbound') > 0 
     AND COUNT(*) FILTER (WHERE eq.direction = 'outbound') > 0) as is_conversation,
    -- Is noise thread: ALL emails are marked as noise
    (COUNT(*) FILTER (WHERE eq.is_noise = FALSE) = 0) as is_noise_thread,
    -- First/latest of each direction
    MIN(eq.external_id) FILTER (WHERE eq.direction = 'inbound') as first_inbound_id,
    MIN(eq.external_id) FILTER (WHERE eq.direction = 'outbound') as first_outbound_id,
    MAX(eq.external_id) FILTER (WHERE eq.direction = 'inbound') as latest_inbound_id,
    MAX(eq.external_id) FILTER (WHERE eq.direction = 'outbound') as latest_outbound_id,
    -- Needs body fetch: is a conversation AND not all noise
    (COUNT(*) FILTER (WHERE eq.direction = 'inbound') > 0 
     AND COUNT(*) FILTER (WHERE eq.direction = 'outbound') > 0
     AND COUNT(*) FILTER (WHERE eq.is_noise = FALSE) > 0) as needs_body_fetch
  FROM email_import_queue eq
  WHERE eq.workspace_id = p_workspace_id
    AND eq.job_id = p_job_id
  GROUP BY eq.thread_id;
  
  -- Get counts
  SELECT COUNT(*) INTO v_threads_analyzed
  FROM email_thread_analysis WHERE job_id = p_job_id;
  
  SELECT COUNT(*) INTO v_conversation_threads
  FROM email_thread_analysis WHERE job_id = p_job_id AND is_conversation = TRUE;
  
  SELECT COUNT(*) INTO v_noise_threads
  FROM email_thread_analysis WHERE job_id = p_job_id AND is_noise_thread = TRUE;
  
  -- Update job
  UPDATE email_import_jobs SET
    total_threads_found = v_threads_analyzed,
    conversation_threads = v_conversation_threads,
    updated_at = NOW()
  WHERE id = p_job_id;
  
  RETURN QUERY SELECT v_threads_analyzed, v_conversation_threads, v_noise_threads;
END;
$$;


-- ============================================================
-- FUNCTION: get_emails_to_fetch
-- Returns emails that need body fetching (prioritized)
-- ============================================================
CREATE OR REPLACE FUNCTION get_emails_to_fetch(
  p_workspace_id UUID, 
  p_job_id UUID, 
  p_limit INT DEFAULT 50
)
RETURNS TABLE(
  external_id TEXT,
  thread_id TEXT,
  direction TEXT,
  from_email TEXT,
  subject TEXT
)
LANGUAGE SQL
AS $$
  SELECT 
    eq.external_id,
    eq.thread_id,
    eq.direction,
    eq.from_email,
    eq.subject
  FROM email_import_queue eq
  INNER JOIN email_thread_analysis eta 
    ON eq.thread_id = eta.thread_id 
    AND eq.workspace_id = eta.workspace_id
  WHERE eq.workspace_id = p_workspace_id
    AND eq.job_id = p_job_id
    AND eq.status = 'queued_for_fetch'
    AND eq.is_noise = FALSE
    AND eta.needs_body_fetch = TRUE
    AND eta.bodies_fetched = FALSE
  ORDER BY eq.received_at DESC
  LIMIT p_limit;
$$;


-- ============================================================
-- FUNCTION: mark_noise_emails
-- Marks emails from known noise senders
-- ============================================================
CREATE OR REPLACE FUNCTION mark_noise_emails(p_workspace_id UUID, p_job_id UUID)
RETURNS INT
LANGUAGE plpgsql
AS $$
DECLARE
  v_marked INT;
BEGIN
  -- Mark emails from noise domains/patterns
  UPDATE email_import_queue SET
    is_noise = TRUE,
    noise_reason = CASE
      -- Noreply addresses
      WHEN from_email LIKE '%noreply%' THEN 'noreply'
      WHEN from_email LIKE '%no-reply%' THEN 'noreply'
      WHEN from_email LIKE '%donotreply%' THEN 'noreply'
      
      -- Common notification domains
      WHEN from_email LIKE '%@stripe.com' THEN 'payment_notification'
      WHEN from_email LIKE '%@paypal.com' THEN 'payment_notification'
      WHEN from_email LIKE '%@square.com' THEN 'payment_notification'
      WHEN from_email LIKE '%@gocardless.com' THEN 'payment_notification'
      
      -- Job boards
      WHEN from_email LIKE '%@indeed.com' THEN 'job_board'
      WHEN from_email LIKE '%@linkedin.com' THEN 'job_board'
      WHEN from_email LIKE '%@glassdoor.com' THEN 'job_board'
      WHEN from_email LIKE '%@reed.co.uk' THEN 'job_board'
      
      -- Social media
      WHEN from_email LIKE '%@facebook.com' THEN 'social_notification'
      WHEN from_email LIKE '%@facebookmail.com' THEN 'social_notification'
      WHEN from_email LIKE '%@twitter.com' THEN 'social_notification'
      WHEN from_email LIKE '%@instagram.com' THEN 'social_notification'
      
      -- Marketing/newsletters
      WHEN from_email LIKE '%@mailchimp.com' THEN 'newsletter'
      WHEN from_email LIKE '%@sendgrid.net' THEN 'newsletter'
      WHEN from_email LIKE '%@amazonses.com' THEN 'newsletter'
      WHEN from_email LIKE '%newsletter%' THEN 'newsletter'
      WHEN from_email LIKE '%marketing%' THEN 'newsletter'
      
      -- System emails
      WHEN from_email LIKE 'mailer-daemon%' THEN 'system'
      WHEN from_email LIKE 'postmaster%' THEN 'system'
      WHEN from_email LIKE '%@google.com' AND subject LIKE '%Security%' THEN 'system'
      
      -- Shipping/logistics
      WHEN from_email LIKE '%@royalmail.com' THEN 'shipping'
      WHEN from_email LIKE '%@dhl.com' THEN 'shipping'
      WHEN from_email LIKE '%@fedex.com' THEN 'shipping'
      WHEN from_email LIKE '%@ups.com' THEN 'shipping'
      WHEN from_email LIKE '%@dpd.co.uk' THEN 'shipping'
      
      ELSE 'other_noise'
    END,
    status = 'skipped'
  WHERE workspace_id = p_workspace_id
    AND job_id = p_job_id
    AND is_noise = FALSE
    AND (
      -- Noreply patterns
      from_email LIKE '%noreply%'
      OR from_email LIKE '%no-reply%'
      OR from_email LIKE '%donotreply%'
      -- Payment
      OR from_email LIKE '%@stripe.com'
      OR from_email LIKE '%@paypal.com'
      OR from_email LIKE '%@square.com'
      OR from_email LIKE '%@gocardless.com'
      -- Job boards
      OR from_email LIKE '%@indeed.com'
      OR from_email LIKE '%@linkedin.com'
      OR from_email LIKE '%@glassdoor.com'
      OR from_email LIKE '%@reed.co.uk'
      -- Social
      OR from_email LIKE '%@facebook.com'
      OR from_email LIKE '%@facebookmail.com'
      OR from_email LIKE '%@twitter.com'
      OR from_email LIKE '%@instagram.com'
      -- Marketing
      OR from_email LIKE '%@mailchimp.com'
      OR from_email LIKE '%@sendgrid.net'
      OR from_email LIKE '%@amazonses.com'
      OR from_email LIKE '%newsletter%'
      OR from_email LIKE '%marketing%'
      -- System
      OR from_email LIKE 'mailer-daemon%'
      OR from_email LIKE 'postmaster%'
      -- Shipping
      OR from_email LIKE '%@royalmail.com'
      OR from_email LIKE '%@dhl.com'
      OR from_email LIKE '%@fedex.com'
      OR from_email LIKE '%@ups.com'
      OR from_email LIKE '%@dpd.co.uk'
    );
  
  GET DIAGNOSTICS v_marked = ROW_COUNT;
  RETURN v_marked;
END;
$$;


-- ============================================================
-- FUNCTION: get_import_job_stats
-- Returns detailed stats for UI display
-- ============================================================
CREATE OR REPLACE FUNCTION get_import_job_stats(p_job_id UUID)
RETURNS TABLE(
  status TEXT,
  inbox_scanned INT,
  sent_scanned INT,
  total_scanned INT,
  threads_found INT,
  conversation_threads INT,
  noise_emails INT,
  bodies_fetched INT,
  messages_created INT,
  progress_percent INT,
  estimated_remaining_seconds INT
)
LANGUAGE SQL
AS $$
  SELECT 
    j.status,
    j.inbox_emails_scanned,
    j.sent_emails_scanned,
    j.inbox_emails_scanned + j.sent_emails_scanned as total_scanned,
    j.total_threads_found,
    j.conversation_threads,
    (SELECT COUNT(*)::INT FROM email_import_queue WHERE job_id = p_job_id AND is_noise = TRUE),
    j.bodies_fetched,
    j.messages_created,
    -- Progress percent (rough estimate)
    CASE 
      WHEN j.status = 'completed' THEN 100
      WHEN j.status IN ('scanning_inbox', 'scanning_sent') THEN 
        LEAST(30, (j.inbox_emails_scanned + j.sent_emails_scanned) / 100)
      WHEN j.status = 'analyzing' THEN 40
      WHEN j.status = 'fetching' THEN 
        40 + LEAST(50, (j.bodies_fetched * 50 / GREATEST(j.conversation_threads, 1)))
      WHEN j.status = 'training' THEN 95
      ELSE 0
    END as progress_percent,
    -- Estimated time remaining (rough)
    CASE 
      WHEN j.status = 'fetching' AND j.bodies_fetched > 0 THEN
        ((j.conversation_threads - j.bodies_fetched) * 
         EXTRACT(EPOCH FROM (NOW() - j.started_at)) / j.bodies_fetched)::INT
      ELSE NULL
    END as estimated_remaining_seconds
  FROM email_import_jobs j
  WHERE j.id = p_job_id;
$$;


-- ============================================================
-- Trigger to update updated_at
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS update_email_import_jobs_updated_at ON email_import_jobs;
CREATE TRIGGER update_email_import_jobs_updated_at
    BEFORE UPDATE ON email_import_jobs
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();


-- ============================================================
-- Grant permissions (adjust as needed)
-- ============================================================
-- GRANT ALL ON email_import_jobs TO authenticated;
-- GRANT ALL ON email_import_queue TO authenticated;
-- GRANT ALL ON email_fetch_retries TO authenticated;
-- GRANT ALL ON email_thread_analysis TO authenticated;
