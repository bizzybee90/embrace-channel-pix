# BIZZYBEE EMAIL IMPORT SYSTEM - LOVABLE INSTRUCTIONS

## Overview

This document contains everything needed to deploy a new, fast, reliable email import system for BizzyBee. The new system is **5-10x faster** than the current approach and includes reliability features like checkpointing and retry logic.

### Architecture Summary

```
┌─────────────────────────────────────────────────────────────┐
│  PHASE 1: SCAN (2-3 minutes)                                │
│  Metadata only, no body fetches                             │
│  ~500 emails/second                                         │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  PHASE 2: ANALYZE (10-30 seconds)                           │
│  Mark noise, group threads, identify conversations          │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  PHASE 3: FETCH BODIES (5-15 minutes)                       │
│  Only conversation threads (~15% of emails)                 │
└─────────────────────────────────────────────────────────────┘
```

**Result:** 16,500 emails imported in ~15-20 minutes instead of 2+ hours.

---

## STEP 1: Run Database Migration

Execute this SQL in Supabase SQL Editor. This creates:
- `email_import_jobs` - Job tracking with checkpointing
- `email_import_queue` - Raw email metadata
- `email_thread_analysis` - Thread grouping results
- `email_fetch_retries` - Failed fetches for retry
- Helper functions for analysis

**File:** `migrations/001_create_email_import_tables.sql`

```sql
-- Copy the entire contents of the migration file and run in Supabase SQL Editor
```

---

## STEP 2: Deploy Edge Functions

Deploy these 5 Edge Functions to Supabase:

### 2.1 start-email-import
Entry point - creates job and triggers scan.

**Path:** `supabase/functions/start-email-import/index.ts`

### 2.2 email-scan
Phase 1 - Fast metadata scan with checkpointing.

**Path:** `supabase/functions/email-scan/index.ts`

### 2.3 email-analyze  
Phase 2 - Thread analysis and noise detection.

**Path:** `supabase/functions/email-analyze/index.ts`

### 2.4 email-fetch-bodies
Phase 3 - Selective body fetching.

**Path:** `supabase/functions/email-fetch-bodies/index.ts`

### 2.5 import-watchdog
Monitors and restarts stuck jobs.

**Path:** `supabase/functions/import-watchdog/index.ts`

---

## STEP 3: Update the Email Import Trigger

Replace the current email sync trigger with the new system.

### Current Code (REPLACE THIS):
```typescript
// Wherever you currently call email-sync
await supabase.functions.invoke('email-sync', {
  body: { configId, mode }
});
```

### New Code:
```typescript
// Start the new import system
const { data, error } = await supabase.functions.invoke('start-email-import', {
  body: { configId, mode: 'all' }
});

if (error) {
  console.error('Failed to start import:', error);
} else {
  console.log('Import started:', data.jobId);
}
```

---

## STEP 4: Update Progress UI

The new system uses different tables for progress tracking.

### Query for Job Status:
```typescript
// Get current job status
const { data: job } = await supabase
  .from('email_import_jobs')
  .select('*')
  .eq('config_id', configId)
  .order('created_at', { ascending: false })
  .limit(1)
  .single();

// job.status: 'queued' | 'scanning_inbox' | 'scanning_sent' | 'analyzing' | 'fetching' | 'completed' | 'error'
// job.inbox_emails_scanned: number
// job.sent_emails_scanned: number  
// job.conversation_threads: number
// job.bodies_fetched: number
// job.messages_created: number
```

### Real-time Progress Subscription:
```typescript
// Subscribe to job updates
const subscription = supabase
  .channel('import-progress')
  .on('postgres_changes', {
    event: 'UPDATE',
    schema: 'public',
    table: 'email_import_jobs',
    filter: `id=eq.${jobId}`
  }, (payload) => {
    console.log('Job updated:', payload.new);
    updateProgressUI(payload.new);
  })
  .subscribe();
```

### Progress Bar Calculation:
```typescript
function calculateProgress(job: EmailImportJob): number {
  switch (job.status) {
    case 'queued':
      return 0;
    case 'scanning_inbox':
    case 'scanning_sent':
      // Scanning is 0-30%
      const totalScanned = job.inbox_emails_scanned + job.sent_emails_scanned;
      return Math.min(30, Math.floor(totalScanned / 500)); // Rough estimate
    case 'analyzing':
      return 35;
    case 'fetching':
      // Fetching is 40-95%
      if (job.conversation_threads > 0) {
        const fetchProgress = (job.bodies_fetched / job.conversation_threads) * 55;
        return Math.min(95, 40 + fetchProgress);
      }
      return 40;
    case 'completed':
      return 100;
    case 'error':
      return -1; // Handle error state
    default:
      return 0;
  }
}
```

---

## STEP 5: Update Progress UI Component

Replace the current progress display with this improved version:

```tsx
interface EmailImportProgressProps {
  configId: string;
}

export function EmailImportProgress({ configId }: EmailImportProgressProps) {
  const [job, setJob] = useState<any>(null);
  
  useEffect(() => {
    // Initial fetch
    fetchJob();
    
    // Subscribe to updates
    const channel = supabase
      .channel(`import-${configId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'email_import_jobs',
        filter: `config_id=eq.${configId}`
      }, (payload) => {
        setJob(payload.new);
      })
      .subscribe();
    
    return () => { supabase.removeChannel(channel); };
  }, [configId]);
  
  if (!job) return <div>Loading...</div>;
  
  const progress = calculateProgress(job);
  
  return (
    <div className="space-y-4">
      {/* Status Badge */}
      <div className="flex items-center gap-2">
        <StatusBadge status={job.status} />
        <span className="text-sm text-gray-500">
          {getStatusMessage(job)}
        </span>
      </div>
      
      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div 
          className="bg-yellow-500 h-2 rounded-full transition-all duration-500"
          style={{ width: `${Math.max(0, progress)}%` }}
        />
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
        <Stat 
          label="Emails Scanned" 
          value={job.inbox_emails_scanned + job.sent_emails_scanned} 
        />
        <Stat 
          label="Conversations Found" 
          value={job.conversation_threads} 
        />
        <Stat 
          label="Bodies Fetched" 
          value={job.bodies_fetched} 
        />
        <Stat 
          label="Messages Created" 
          value={job.messages_created} 
        />
      </div>
      
      {/* Error Display */}
      {job.status === 'error' && (
        <div className="p-3 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
          {job.error_message}
        </div>
      )}
    </div>
  );
}

function getStatusMessage(job: any): string {
  switch (job.status) {
    case 'queued':
      return 'Preparing to scan...';
    case 'scanning_inbox':
      return `Scanning inbox... ${job.inbox_emails_scanned.toLocaleString()} emails found`;
    case 'scanning_sent':
      return `Scanning sent folder... ${job.sent_emails_scanned.toLocaleString()} emails found`;
    case 'analyzing':
      return 'Analyzing threads and filtering noise...';
    case 'fetching':
      return `Importing conversations... ${job.bodies_fetched} of ${job.conversation_threads}`;
    case 'completed':
      return `Complete! ${job.messages_created} messages imported`;
    case 'error':
      return 'Import failed';
    default:
      return job.status;
  }
}
```

---

## STEP 6: Set Up Watchdog Cron (Optional but Recommended)

Add this to your Supabase database to automatically restart stuck jobs:

```sql
-- Enable pg_cron extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Create the cron job (runs every 5 minutes)
SELECT cron.schedule(
  'email-import-watchdog',
  '*/5 * * * *',
  $$
  SELECT net.http_post(
    url := current_setting('app.settings.supabase_url') || '/functions/v1/import-watchdog',
    headers := jsonb_build_object(
      'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key'),
      'Content-Type', 'application/json'
    ),
    body := '{}'::jsonb
  );
  $$
);
```

---

## STEP 7: Clean Up Old Code (Optional)

Once the new system is working, you can remove:
- `email-sync/index.ts` (old sync function)
- `email-sync-worker/index.ts` (old worker)
- Related old tables if no longer needed

---

## Key Differences from Old System

| Aspect | Old System | New System |
|--------|------------|------------|
| **Body fetches** | Every email (16,500) | Only conversations (~2,500) |
| **Time** | 2+ hours | 15-20 minutes |
| **Checkpointing** | Limited | Full - resume from any point |
| **Error handling** | Basic | Retry queue with backoff |
| **Stuck jobs** | Manual fix | Auto-restart via watchdog |
| **Progress tracking** | Single counter | Detailed per-phase stats |

---

## Testing the New System

1. Connect a Gmail account via Aurinko
2. Click "Import Emails" 
3. Watch the progress UI update in real-time
4. Check Supabase logs for Edge Function output
5. Verify conversations created in `conversations` table
6. Verify messages created in `messages` table

---

## Troubleshooting

### Job stuck in "scanning" state
- Watchdog should auto-restart after 5 min
- Check Edge Function logs for errors
- Manually invoke `email-scan` with `resume: true`

### No conversations created
- Check `email_thread_analysis` table
- Look for `is_conversation = true` rows
- If none, the inbox might not have reply threads

### Rate limited by Aurinko
- System will auto-retry with backoff
- Check `email_fetch_retries` table for queued retries

### Token expired
- Job will fail with "Access token expired" error
- User needs to reconnect their email account

---

## Files Included

```
bizzybee-email-import/
├── migrations/
│   └── 001_create_email_import_tables.sql
├── supabase/
│   └── functions/
│       ├── start-email-import/
│       │   └── index.ts
│       ├── email-scan/
│       │   └── index.ts
│       ├── email-analyze/
│       │   └── index.ts
│       ├── email-fetch-bodies/
│       │   └── index.ts
│       └── import-watchdog/
│           └── index.ts
└── LOVABLE_INSTRUCTIONS.md (this file)
```

---

## Questions?

If you run into issues, check:
1. Supabase Edge Function logs
2. `email_import_jobs` table for job status
3. `email_import_queue` table for individual email status
4. `email_fetch_retries` table for failed fetches
